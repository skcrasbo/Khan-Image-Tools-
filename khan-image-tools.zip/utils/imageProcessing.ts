
// Utility functions for image manipulation

export const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
};

export const getCanvas = (w: number, h: number) => {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  return canvas;
};

// --- CORE FILTERS ---

const clamp = (v: number) => Math.max(0, Math.min(255, v));

export const applyConvolution = (ctx: CanvasRenderingContext2D, w: number, h: number, kernel: number[]) => {
  const imageData = ctx.getImageData(0, 0, w, h);
  const side = Math.round(Math.sqrt(kernel.length));
  const halfSide = Math.floor(side / 2);
  const src = imageData.data;
  const output = ctx.createImageData(w, h);
  const dst = output.data;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dstOff = (y * w + x) * 4;
      let r = 0, g = 0, b = 0;

      for (let cy = 0; cy < side; cy++) {
        for (let cx = 0; cx < side; cx++) {
          const scy = y + cy - halfSide;
          const scx = x + cx - halfSide;
          if (scy >= 0 && scy < h && scx >= 0 && scx < w) {
            const srcOff = (scy * w + scx) * 4;
            const wt = kernel[cy * side + cx];
            r += src[srcOff] * wt;
            g += src[srcOff + 1] * wt;
            b += src[srcOff + 2] * wt;
          }
        }
      }
      dst[dstOff] = clamp(r);
      dst[dstOff + 1] = clamp(g);
      dst[dstOff + 2] = clamp(b);
      dst[dstOff + 3] = src[dstOff + 3]; // Alpha
    }
  }
  ctx.putImageData(output, 0, 0);
};

export const applyFilter = (
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  filterType: string,
  intensity: number = 0.5 // 0 to 1
) => {
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const original = new Uint8ClampedArray(data); // Store original for blending

  if (filterType === 'emboss') {
      applyConvolution(ctx, width, height, [-2, -1, 0, -1, 1, 1, 0, 1, 2]);
      return;
  }
  if (filterType === 'sharpen') {
      applyConvolution(ctx, width, height, [0, -1, 0, -1, 5, -1, 0, -1, 0]);
      return;
  }

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    if (filterType === 'grayscale' || filterType === 'black_white') {
      const avg = (r + g + b) / 3;
      if (filterType === 'black_white') {
          const threshold = intensity * 255;
          const val = avg > threshold ? 255 : 0;
          r = g = b = val;
      } else {
          // Weighted grayscale for realism
          const gray = 0.299 * r + 0.587 * g + 0.114 * b;
          r = g = b = gray;
      }
    } else if (filterType === 'sepia') {
      const tr = r * 0.393 + g * 0.769 + b * 0.189;
      const tg = r * 0.349 + g * 0.686 + b * 0.168;
      const tb = r * 0.272 + g * 0.534 + b * 0.131;
      r = tr; g = tg; b = tb;
    } else if (filterType === 'invert') {
      r = 255 - r;
      g = 255 - g;
      b = 255 - b;
    } else if (filterType === 'brownie') {
      r = r * 0.5 + g * 0.4 + b * 0.2; 
      g = r * 0.4 + g * 0.5 + b * 0.2;
      b = r * 0.2 + g * 0.3 + b * 0.6;
    } else if (filterType === 'vintage') {
      r = r * 0.9 + 40;
      g = g * 0.7 + 20;
      b = b * 0.6 + 20;
    } else if (filterType === 'kodachrome') {
      r = (r - g + b) * 1.2 + 20;
      g = (g - b) * 1.1 + 40;
      b = b * 0.9;
    } else if (filterType === 'technicolor') {
      r = r * 1.3 - g * 0.2;
      g = g * 1.3 - b * 0.2;
      b = b * 1.3 - r * 0.2;
    } else if (filterType === 'polaroid') {
       r = r * 1.1 + 20;
       g = g * 1.1 + 10;
       b = b * 0.9 + 40;
    } else if (filterType === 'noise') {
      const noise = (Math.random() - 0.5) * 255 * intensity;
      r += noise; g += noise; b += noise;
    } else if (filterType === 'gamma') {
      const gVal = 1 / (intensity * 4 + 0.1); 
      r = 255 * Math.pow(r / 255, gVal);
      g = 255 * Math.pow(g / 255, gVal);
      b = 255 * Math.pow(b / 255, gVal);
    } else if (filterType === 'exposure') {
      const exp = Math.pow(2, (intensity * 4) - 2); // -2 to +2 range
      r *= exp; g *= exp; b *= exp;
    } else if (filterType === 'brightness') {
       const val = (intensity - 0.5) * 255; 
       r += val; g += val; b += val;
    } else if (filterType === 'contrast') {
       const contrast = (intensity * 255); 
       const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
       r = factor * (r - 128) + 128;
       g = factor * (g - 128) + 128;
       b = factor * (b - 128) + 128;
    } else if (filterType === 'darken') {
        const val = intensity * 255;
        r -= val; g -= val; b -= val;
    } else if (filterType === 'lighten') {
        const val = intensity * 255;
        r += val; g += val; b += val;
    }

    // Blend back with original based on intensity for specific filters
    if (['grayscale', 'sepia', 'invert', 'brownie', 'vintage', 'kodachrome', 'technicolor', 'polaroid'].includes(filterType)) {
        const mix = intensity; 
        data[i] = clamp(original[i] * (1 - mix) + r * mix);
        data[i + 1] = clamp(original[i+1] * (1 - mix) + g * mix);
        data[i + 2] = clamp(original[i+2] * (1 - mix) + b * mix);
    } else {
        data[i] = clamp(r);
        data[i + 1] = clamp(g);
        data[i + 2] = clamp(b);
    }
  }
  ctx.putImageData(imageData, 0, 0);
};

export const applyHSLVibrance = (ctx: CanvasRenderingContext2D, w: number, h: number, type: 'saturation'|'lightness'|'hue'|'vibrance'|'hsl', value: number, sVal?: number, lVal?: number) => {
   const imageData = ctx.getImageData(0,0,w,h);
   const data = imageData.data;
   
   for(let i=0; i<data.length; i+=4) {
      const r = data[i]/255, g = data[i+1]/255, b = data[i+2]/255;
      const max = Math.max(r,g,b), min = Math.min(r,g,b);
      let h_val=0, s=0, l=(max+min)/2;
      
      if(max !== min){
        const d = max-min;
        s = l > 0.5 ? d/(2-max-min) : d/(max+min);
        switch(max){
            case r: h_val = (g-b)/d + (g<b ? 6 : 0); break;
            case g: h_val = (b-r)/d + 2; break;
            case b: h_val = (r-g)/d + 4; break;
        }
        h_val /= 6;
      }

      if (type === 'saturation') s = Math.max(0, Math.min(1, s + value/100));
      if (type === 'hue') h_val = (h_val + value/360) % 1;
      if (type === 'hsl') {
          h_val = (h_val + value/360) % 1;
          s = Math.max(0, Math.min(1, s + (sVal||0)/100));
          l = Math.max(0, Math.min(1, l + (lVal||0)/100));
      }
      if (type === 'vibrance') {
          const avg = (r+g+b)/3;
          const maxDist = max - avg; 
          if (maxDist < 0.5) { 
             s = Math.max(0, Math.min(1, s + (value/100) * (1-s)));
          }
      }

      let r1,g1,b1;
      if(s === 0) {
        r1=g1=b1=l;
      } else {
        const q = l < 0.5 ? l*(1+s) : l+s-l*s;
        const p = 2*l - q;
        const hue2rgb = (p: number, q: number, t: number) => {
            if(t < 0) t += 1;
            if(t > 1) t -= 1;
            if(t < 1/6) return p + (q-p) * 6 * t;
            if(t < 1/2) return q;
            if(t < 2/3) return p + (q-p) * (2/3 - t) * 6;
            return p;
        }
        r1 = hue2rgb(p, q, h_val + 1/3);
        g1 = hue2rgb(p, q, h_val);
        b1 = hue2rgb(p, q, h_val - 1/3);
      }
      data[i] = r1*255;
      data[i+1] = g1*255;
      data[i+2] = b1*255;
   }
   ctx.putImageData(imageData, 0, 0);
}

// --- MANIPULATION ---

export const applyFlip = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, horizontal: boolean) => {
    ctx.clearRect(0,0,ctx.canvas.width, ctx.canvas.height);
    ctx.save();
    if(horizontal) {
        ctx.scale(-1, 1);
        ctx.drawImage(img, -img.width, 0);
    } else {
        ctx.scale(1, -1);
        ctx.drawImage(img, 0, -img.height);
    }
    ctx.restore();
}

export const applySymmetric = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, w: number, h: number, horizontal: boolean) => {
    ctx.drawImage(img, 0, 0); 
    ctx.save(); 
    
    if (horizontal) {
        ctx.translate(w, 0); 
        ctx.scale(-1, 1);
        ctx.drawImage(img, 0, 0, w/2, h, 0, 0, w/2, h); 
    } else {
        ctx.translate(0, h);
        ctx.scale(1, -1);
        ctx.drawImage(img, 0, 0, w, h/2, 0, 0, w, h/2);
    }
    
    ctx.restore();
}

export const applyRotate = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, angle: number) => {
    const w = ctx.canvas.width;
    const h = ctx.canvas.height;
    ctx.clearRect(0,0,w,h);
    ctx.save();
    ctx.translate(w/2, h/2);
    ctx.rotate(angle * Math.PI / 180);
    ctx.drawImage(img, -img.width/2, -img.height/2);
    ctx.restore();
}

export const applyRoundCorners = (ctx: CanvasRenderingContext2D, w: number, h: number, radius: number) => {
    const temp = getCanvas(w, h);
    temp.getContext('2d')?.drawImage(ctx.canvas, 0, 0);
    
    ctx.clearRect(0, 0, w, h);
    ctx.beginPath();
    ctx.moveTo(radius, 0);
    ctx.lineTo(w - radius, 0);
    ctx.quadraticCurveTo(w, 0, w, radius);
    ctx.lineTo(w, h - radius);
    ctx.quadraticCurveTo(w, h, w - radius, h);
    ctx.lineTo(radius, h);
    ctx.quadraticCurveTo(0, h, 0, h - radius);
    ctx.lineTo(0, radius);
    ctx.quadraticCurveTo(0, 0, radius, 0);
    ctx.closePath();
    ctx.clip();
    
    ctx.drawImage(temp, 0, 0);
}

export const applyCropCircle = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    const temp = getCanvas(w, h);
    temp.getContext('2d')?.drawImage(ctx.canvas, 0, 0);
    
    ctx.clearRect(0, 0, w, h);
    ctx.beginPath();
    const r = Math.min(w, h) / 2;
    ctx.arc(w/2, h/2, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    
    ctx.drawImage(temp, 0, 0);
}

export const applyGrid = (ctx: CanvasRenderingContext2D, w: number, h: number, size: number, color: string) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    for(let x=0; x<w; x+=size) {
        ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke();
    }
    for(let y=0; y<h; y+=size) {
        ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke();
    }
}

export const applyChessboard = (ctx: CanvasRenderingContext2D, w: number, h: number, size: number) => {
    ctx.fillStyle = 'rgba(200, 200, 200, 0.5)';
    for(let y=0; y<h; y+=size) {
        for(let x=0; x<w; x+=size) {
            if(((x+y)/size)%2 === 0) ctx.fillRect(x,y,size,size);
        }
    }
}

export const applyBorder = (ctx: CanvasRenderingContext2D, w: number, h: number, thickness: number, color: string) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = thickness;
    ctx.strokeRect(thickness/2, thickness/2, w-thickness, h-thickness);
}

export const applyBlur = (ctx: CanvasRenderingContext2D, width: number, height: number, radius: number) => {
  if (radius <= 0) return;
  ctx.filter = `blur(${radius}px)`;
  const tempCanvas = getCanvas(width, height);
  const tempCtx = tempCanvas.getContext('2d');
  if(!tempCtx) return;
  tempCtx.drawImage(ctx.canvas, 0, 0);
  ctx.clearRect(0,0,width,height);
  ctx.drawImage(tempCanvas, 0, 0);
  ctx.filter = 'none';
};

export const applyPixelate = (ctx: CanvasRenderingContext2D, w: number, h: number, size: number) => {
  if (size <= 1) return;
  const sw = Math.ceil(w / size);
  const sh = Math.ceil(h / size);
  const tempCanvas = getCanvas(sw, sh);
  const tempCtx = tempCanvas.getContext('2d');
  if(!tempCtx) return;
  tempCtx.imageSmoothingEnabled = false;
  tempCtx.drawImage(ctx.canvas, 0, 0, sw, sh);
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0,0,w,h);
  ctx.drawImage(tempCanvas, 0, 0, sw, sh, 0, 0, w, h);
  ctx.imageSmoothingEnabled = true;
};

// --- ADVANCED MANIPULATION ---

export const applyRemoveColor = (ctx: CanvasRenderingContext2D, w: number, h: number, targetColor: {r:number, g:number, b:number}, threshold: number) => {
    const imageData = ctx.getImageData(0,0,w,h);
    const data = imageData.data;
    const thresh = threshold * 4.4; // approx range
    for(let i=0; i<data.length; i+=4) {
        const r=data[i], g=data[i+1], b=data[i+2];
        const dist = Math.sqrt(Math.pow(r-targetColor.r,2) + Math.pow(g-targetColor.g,2) + Math.pow(b-targetColor.b,2));
        if(dist < thresh) {
            data[i+3] = 0;
        }
    }
    ctx.putImageData(imageData, 0, 0);
}

export const applyReplaceColor = (ctx: CanvasRenderingContext2D, w: number, h: number, target: {r:number, g:number, b:number}, replace: {r:number, g:number, b:number}, threshold: number) => {
    const imageData = ctx.getImageData(0,0,w,h);
    const data = imageData.data;
    const thresh = threshold * 4.4;
    for(let i=0; i<data.length; i+=4) {
        const r=data[i], g=data[i+1], b=data[i+2];
        const dist = Math.sqrt(Math.pow(r-target.r,2) + Math.pow(g-target.g,2) + Math.pow(b-target.b,2));
        if(dist < thresh) {
            data[i] = replace.r;
            data[i+1] = replace.g;
            data[i+2] = replace.b;
        }
    }
    ctx.putImageData(imageData, 0, 0);
}

export const applyFillTransparent = (ctx: CanvasRenderingContext2D, w: number, h: number, color: {r:number, g:number, b:number}) => {
    const imageData = ctx.getImageData(0,0,w,h);
    const data = imageData.data;
    for(let i=0; i<data.length; i+=4) {
        if(data[i+3] === 0) {
            data[i] = color.r;
            data[i+1] = color.g;
            data[i+2] = color.b;
            data[i+3] = 255;
        }
    }
    ctx.putImageData(imageData, 0, 0);
}

export const applyShift = (ctx: CanvasRenderingContext2D, w: number, h: number, dx: number, dy: number) => {
    const temp = getCanvas(w,h);
    temp.getContext('2d')?.drawImage(ctx.canvas,0,0);
    ctx.clearRect(0,0,w,h);
    // Wrap around
    ctx.drawImage(temp, dx, dy);
    ctx.drawImage(temp, dx - w, dy);
    ctx.drawImage(temp, dx, dy - h);
    ctx.drawImage(temp, dx - w, dy - h);
}

export const applyOverlay = (ctx: CanvasRenderingContext2D, w: number, h: number, color: string, alpha: number) => {
    ctx.fillStyle = color;
    ctx.globalAlpha = alpha;
    ctx.fillRect(0,0,w,h);
    ctx.globalAlpha = 1;
}

export const applyColorPalette = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
   const imageData = ctx.getImageData(0,0,w,h);
   const data = imageData.data;
   const colors = [];
   for(let i=0; i<5; i++) {
       const idx = Math.floor(Math.random() * (data.length/4)) * 4;
       colors.push(`rgb(${data[idx]},${data[idx+1]},${data[idx+2]})`);
   }
   const barH = h * 0.1;
   const barW = w / 5;
   for(let i=0; i<5; i++) {
       ctx.fillStyle = colors[i];
       ctx.fillRect(i*barW, h-barH, barW, barH);
   }
}
