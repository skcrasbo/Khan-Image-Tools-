
// Pure Canvas Charting Engine for Khan Tools

export interface ChartConfig {
    type: string;
    labels: string[];
    data: number[]; 
    colors: string[];
    title: string;
}

const PADDING = 40;
const FONT = "12px 'Courier New'";

export const renderChart = (ctx: CanvasRenderingContext2D, w: number, h: number, config: ChartConfig) => {
    const { type, labels, data, colors, title } = config;
    ctx.clearRect(0, 0, w, h);
    
    // Background
    ctx.fillStyle = "#111";
    ctx.fillRect(0,0,w,h);
    
    // Title
    ctx.fillStyle = "#f00";
    ctx.font = "bold 16px 'Courier New'";
    ctx.textAlign = "center";
    ctx.fillText(title.toUpperCase(), w/2, 25);

    const chartW = w - PADDING * 2;
    const chartH = h - PADDING * 2 - 20;
    const originX = PADDING;
    const originY = h - PADDING;
    
    const maxVal = Math.max(...data) || 100;

    ctx.font = FONT;

    // --- BAR CHARTS ---
    if (type === 'bar_chart' || type === 'vertical_bar_chart') {
        const barW = chartW / data.length;
        const gap = barW * 0.2;
        data.forEach((val, i) => {
            const bh = (val / maxVal) * chartH;
            const x = originX + i * barW + gap/2;
            const y = originY - bh;
            ctx.fillStyle = colors[i % colors.length];
            ctx.fillRect(x, y, barW - gap, bh);
            ctx.fillStyle = "#aaa";
            ctx.textAlign = "center";
            ctx.fillText(labels[i]?.substring(0, 5) || '', x + (barW-gap)/2, originY + 15);
        });
    }
    
    else if (type === 'horizontal_bar_chart') {
        const barH = chartH / data.length;
        const gap = barH * 0.2;
        data.forEach((val, i) => {
            const bw = (val / maxVal) * chartW;
            const y = originY - (i+1) * barH + gap/2;
            const x = originX;
            ctx.fillStyle = colors[i % colors.length];
            ctx.fillRect(x, y, bw, barH - gap);
            ctx.fillStyle = "#aaa";
            ctx.textAlign = "right";
            ctx.fillText(labels[i] || '', x - 5, y + barH/2);
        });
    }

    else if (type === 'vertical_stacked_bar_chart' || type === 'horizontal_stacked_bar_chart') {
        // Simulate stacked by drawing segments. Since we only have 1 dataset input,
        // we'll split the value into 3 random segments for the demo.
        const isVert = type === 'vertical_stacked_bar_chart';
        const barSize = (isVert ? chartW : chartH) / data.length;
        const gap = barSize * 0.2;

        data.forEach((val, i) => {
            const seg1 = val * 0.4;
            const seg2 = val * 0.3;
            const seg3 = val * 0.3;
            const segs = [seg1, seg2, seg3];
            
            let currentPos = 0;
            segs.forEach((seg, sIdx) => {
                 const size = (seg / maxVal) * (isVert ? chartH : chartW);
                 ctx.fillStyle = colors[(i+sIdx) % colors.length];
                 
                 if(isVert) {
                     const x = originX + i * barSize + gap/2;
                     const y = originY - currentPos - size;
                     ctx.fillRect(x, y, barSize - gap, size);
                     currentPos += size;
                 } else {
                     const y = originY - (i+1) * barSize + gap/2;
                     const x = originX + currentPos;
                     ctx.fillRect(x, y, size, barSize - gap);
                     currentPos += size;
                 }
            });
            
             // Label
            if(isVert) {
                ctx.fillStyle = "#aaa";
                ctx.textAlign = "center";
                ctx.fillText(labels[i]?.substring(0, 5) || '', originX + i * barSize + barSize/2, originY + 15);
            }
        });
    }

    // --- LINE & AREA ---
    else if (type === 'line_chart' || type === 'area_chart') {
        const stepX = chartW / (data.length - 1 || 1);
        ctx.beginPath();
        data.forEach((val, i) => {
            const x = originX + i * stepX;
            const y = originY - (val / maxVal) * chartH;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        
        if (type === 'area_chart') {
            ctx.lineTo(originX + (data.length - 1) * stepX, originY);
            ctx.lineTo(originX, originY);
            ctx.closePath();
            ctx.fillStyle = "rgba(200, 0, 0, 0.3)";
            ctx.fill();
        }
        
        ctx.strokeStyle = colors[0];
        ctx.lineWidth = 2;
        ctx.stroke();
        
        data.forEach((val, i) => {
             const x = originX + i * stepX;
             const y = originY - (val / maxVal) * chartH;
             ctx.fillStyle = "#fff";
             ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI*2); ctx.fill();
        });
    }

    // --- PIE VARIATIONS ---
    else if (type === 'pie_chart' || type === 'doughnut_chart' || type === 'half_doughnut_chart' || type === 'polar_area_chart') {
        const cx = w/2;
        const cy = type === 'half_doughnut_chart' ? h - 50 : h/2 + 10;
        const radius = Math.min(chartW, chartH) / 2;
        const total = data.reduce((a,b) => a+b, 0);
        let startAngle = type === 'half_doughnut_chart' ? Math.PI : 0;
        const endMax = type === 'half_doughnut_chart' ? Math.PI * 2 : Math.PI * 2;
        const totalAngle = type === 'half_doughnut_chart' ? Math.PI : Math.PI * 2;

        if (type === 'polar_area_chart') {
             const angleStep = (Math.PI * 2) / data.length;
             data.forEach((val, i) => {
                 const r = (val/maxVal) * radius;
                 ctx.beginPath();
                 ctx.moveTo(cx, cy);
                 ctx.arc(cx, cy, r, i*angleStep, (i+1)*angleStep);
                 ctx.closePath();
                 ctx.fillStyle = colors[i % colors.length];
                 ctx.globalAlpha = 0.8;
                 ctx.fill();
                 ctx.globalAlpha = 1.0;
             });
        } else {
            data.forEach((val, i) => {
                const sliceAngle = (val / total) * totalAngle;
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle);
                ctx.closePath();
                ctx.fillStyle = colors[i % colors.length];
                ctx.fill();
                startAngle += sliceAngle;
            });

            if (type === 'doughnut_chart' || type === 'half_doughnut_chart') {
                ctx.beginPath();
                ctx.arc(cx, cy, radius * 0.5, 0, Math.PI*2);
                ctx.fillStyle = "#111"; 
                ctx.fill();
            }
        }
    }

    // --- SCATTER & BUBBLE ---
    else if (type === 'scatter_chart' || type === 'bubble_chart') {
        // Draw axes
        ctx.strokeStyle = '#333';
        ctx.beginPath(); ctx.moveTo(originX, originY); ctx.lineTo(originX + chartW, originY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(originX, originY); ctx.lineTo(originX, originY - chartH); ctx.stroke();
        
        // Since we only have 1D data input, we map Index -> X, Value -> Y
        // For bubble, Value also -> Radius
        const stepX = chartW / (data.length || 1);
        
        data.forEach((val, i) => {
            const x = originX + i * stepX + stepX/2;
            const y = originY - (val / maxVal) * chartH;
            const r = type === 'bubble_chart' ? (val/maxVal)*20 + 5 : 5;
            
            ctx.fillStyle = colors[i % colors.length];
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI*2);
            ctx.fill();
        });
    }

    else if (type === 'radar_chart') {
        const cx = w/2;
        const cy = h/2 + 10;
        const radius = Math.min(chartW, chartH) / 2;
        const count = data.length;
        const angleStep = (Math.PI * 2) / count;
        
        ctx.strokeStyle = "#333";
        for (let r=0.2; r<=1; r+=0.2) {
             ctx.beginPath();
             for(let i=0; i<=count; i++) {
                 const a = i * angleStep - Math.PI/2;
                 const x = cx + Math.cos(a) * radius * r;
                 const y = cy + Math.sin(a) * radius * r;
                 if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
             }
             ctx.stroke();
        }

        ctx.beginPath();
        data.forEach((val, i) => {
            const a = i * angleStep - Math.PI/2;
            const dist = (val / maxVal) * radius;
            const x = cx + Math.cos(a) * dist;
            const y = cy + Math.sin(a) * dist;
            if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
        });
        ctx.closePath();
        ctx.fillStyle = "rgba(200,0,0,0.5)";
        ctx.fill();
        ctx.strokeStyle = "#f00";
        ctx.stroke();
    }
};
