import React, { useEffect, useRef } from 'react';

const SmokeEffect: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number }[] = [];

    const createParticle = () => {
      particles.push({
        x: Math.random() * width,
        y: height + Math.random() * 100,
        vx: Math.random() * 0.5 - 0.25,
        vy: -Math.random() * 1.5 - 0.5,
        size: Math.random() * 30 + 10,
        alpha: Math.random() * 0.1 + 0.05,
      });
    };

    const animate = () => {
      ctx.clearRect(0, 0, width, height);
      
      // Generate particles
      if (particles.length < 50) {
        createParticle();
      }

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.0005;
        p.size += 0.05;

        if (p.alpha <= 0 || p.y < -50) {
          particles.splice(i, 1);
          i--;
          continue;
        }

        ctx.fillStyle = `rgba(200, 50, 50, ${p.alpha})`; // Reddish smoke
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 opacity-40 mix-blend-screen"
    />
  );
};

export default SmokeEffect;
