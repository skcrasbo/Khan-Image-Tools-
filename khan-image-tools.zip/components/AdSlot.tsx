
import React, { useEffect } from 'react';

interface AdSlotProps {
  type: 'leaderboard' | 'rectangle' | 'sidebar';
  className?: string;
}

// Typing for the global AdSense array
declare global {
  interface Window {
    adsbygoogle: any[];
  }
}

const AdSlot: React.FC<AdSlotProps> = ({ type, className = "" }) => {
  useEffect(() => {
    // Attempt to push the ad. AdSense handles multiple pushes on the same page.
    try {
      if (typeof window !== 'undefined') {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      }
    } catch (e) {
      console.error("AdSense placement error:", e);
    }
  }, []);

  const styles = {
    leaderboard: "w-full min-h-[90px] max-w-[728px]",
    rectangle: "w-full min-h-[250px] max-w-[300px]",
    sidebar: "w-full min-h-[250px]",
  };

  return (
    <div className={`mx-auto bg-[#0a0a0a]/40 border border-red-900/20 flex flex-col items-center justify-center relative overflow-hidden group ${styles[type]} ${className}`}>
      {/* Background Aesthetic */}
      <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(circle_at_center,_#ff0000_0%,_transparent_70%)]"></div>
      
      {/* Real Google AdSense Unit */}
      <ins className="adsbygoogle"
           style={{ display: 'block', width: '100%', height: '100%' }}
           data-ad-client="ca-pub-8261409627439829"
           data-ad-slot="9729125630"
           data-ad-format="auto"
           data-full-width-responsive="true"></ins>

      {/* Label for Crawler/User awareness */}
      <span className="text-[7px] text-red-950 font-mono absolute top-0 right-1 uppercase tracking-tighter">SECURE_AD_NODE</span>

      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-1 h-1 border-t border-l border-red-900/40"></div>
      <div className="absolute bottom-0 right-0 w-1 h-1 border-b border-r border-red-900/40"></div>
    </div>
  );
};

export default AdSlot;
