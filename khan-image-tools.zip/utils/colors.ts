
export const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
};

export const rgbToHex = (r: number, g: number, b: number) => {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
};

export const rgbToHsl = (r: number, g: number, b: number) => {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
};

export const hslToRgb = (h: number, s: number, l: number) => {
    h = h % 360;
    if (h < 0) h += 360;
    h /= 360; s /= 100; l /= 100;
    let r, g, b;
    if (s === 0) {
        r = g = b = l;
    } else {
        const hue2rgb = (p: number, q: number, t: number) => {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1 / 6) return p + (q - p) * 6 * t;
            if (t < 1 / 2) return q;
            if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
            return p;
        };
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
    }
    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
};

// --- MIXING ---
export const mixColors = (c1: string, c2: string, amount: number = 50) => {
    const rgb1 = hexToRgb(c1);
    const rgb2 = hexToRgb(c2);
    const p = amount / 100;
    const r = Math.round(rgb1.r * (1 - p) + rgb2.r * p);
    const g = Math.round(rgb1.g * (1 - p) + rgb2.g * p);
    const b = Math.round(rgb1.b * (1 - p) + rgb2.b * p);
    return rgbToHex(r, g, b);
};

export const generateScheme = (baseHex: string, type: string, intensity: number = 0, colorB?: string): string[] => {
    const rgb = hexToRgb(baseHex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    const colors: string[] = [];

    // Helper to push hex from HSL
    const addHsl = (h: number, s: number, l: number) => {
        const newRgb = hslToRgb(h, s, l);
        colors.push(rgbToHex(newRgb.r, newRgb.g, newRgb.b));
    };

    if (type === 'mixture' && colorB) {
        // Show gradient mixture
        for(let i=0; i<=5; i++) {
            colors.push(mixColors(baseHex, colorB, i*20));
        }
        return colors;
    }

    if (type === 'random') {
        for(let i=0; i<5; i++) {
             colors.push('#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0'));
        }
        return colors;
    }

    // --- SINGLE OPS (Return 1 color but as array) ---
    if (['darken', 'lighten', 'saturate', 'desaturate', 'rotate_hue', 'invert', 'grayscale'].includes(type)) {
        let { h, s, l } = hsl;
        const val = intensity; 
        
        if (type === 'darken') l = Math.max(0, l - val);
        if (type === 'lighten') l = Math.min(100, l + val);
        if (type === 'saturate') s = Math.min(100, s + val);
        if (type === 'desaturate') s = Math.max(0, s - val);
        if (type === 'rotate_hue') h = (h + val * 3.6) % 360; // 0-100 mapped to 0-360
        if (type === 'grayscale') s = 0;
        if (type === 'invert') {
             colors.push(rgbToHex(255-rgb.r, 255-rgb.g, 255-rgb.b));
             return colors;
        }

        addHsl(h, s, l);
        return colors;
    }

    // --- SCHEMES ---
    colors.push(baseHex); // Base is always first

    if (type === 'complementary') addHsl(hsl.h + 180, hsl.s, hsl.l);
    if (type === 'analogous') { addHsl(hsl.h + 30, hsl.s, hsl.l); addHsl(hsl.h - 30, hsl.s, hsl.l); }
    if (type === 'triad') { addHsl(hsl.h + 120, hsl.s, hsl.l); addHsl(hsl.h + 240, hsl.s, hsl.l); }
    if (type === 'tetrad') { addHsl(hsl.h + 90, hsl.s, hsl.l); addHsl(hsl.h + 180, hsl.s, hsl.l); addHsl(hsl.h + 270, hsl.s, hsl.l); }
    if (type === 'split_complementary') { addHsl(hsl.h + 150, hsl.s, hsl.l); addHsl(hsl.h + 210, hsl.s, hsl.l); }
    if (type === 'double_split_complementary') { 
        addHsl(hsl.h + 30, hsl.s, hsl.l); 
        addHsl(hsl.h + 180, hsl.s, hsl.l); 
        addHsl(hsl.h + 210, hsl.s, hsl.l); 
    }
    if (type === 'rectangle') { 
        addHsl(hsl.h + 60, hsl.s, hsl.l); 
        addHsl(hsl.h + 180, hsl.s, hsl.l); 
        addHsl(hsl.h + 240, hsl.s, hsl.l); 
    }
    if (type === 'monochromatic') { addHsl(hsl.h, hsl.s, Math.max(0, hsl.l - 20)); addHsl(hsl.h, hsl.s, Math.min(100, hsl.l + 20)); }
    
    if (type === 'shades') {
        for(let i=1; i<=4; i++) addHsl(hsl.h, hsl.s, Math.max(0, hsl.l - i*15));
    }
    if (type === 'tints') {
        for(let i=1; i<=4; i++) addHsl(hsl.h, hsl.s, Math.min(100, hsl.l + i*15));
    }
    if (type === 'tones') {
        for(let i=1; i<=4; i++) addHsl(hsl.h, Math.max(0, hsl.s - i*20), hsl.l);
    }

    return colors;
};

export const getColorInfo = (hex: string) => {
    const rgb = hexToRgb(hex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    return `HEX: ${hex}\nRGB: ${rgb.r}, ${rgb.g}, ${rgb.b}\nHSL: ${Math.round(hsl.h)}°, ${Math.round(hsl.s)}%, ${Math.round(hsl.l)}%`;
};
