
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ToolDefinition, ToolCategory, ImageState } from '../types';
import { 
  loadImage, getCanvas, applyFilter, applyHSLVibrance, 
  applyFlip, applyRoundCorners, applyGrid, applyBorder, applyBlur, applyPixelate,
  applyCropCircle, applyChessboard, applyRotate, applyRemoveColor, applyReplaceColor,
  applyFillTransparent, applyShift, applyOverlay, applyColorPalette, applySymmetric
} from '../utils/imageProcessing';
import { renderChart, ChartConfig } from '../utils/charting';
import { generateScheme, hexToRgb, rgbToHex, getColorInfo } from '../utils/colors';
import AdSlot from './AdSlot';
import { 
  X, Download, RefreshCw, Upload, Grid, 
  Palette, BarChart2, Layers, MousePointer2, FileText, Copy, ArrowRight,
  MoveHorizontal, MoveVertical, RotateCw
} from 'lucide-react';

interface EditorProps {
  tool: ToolDefinition;
  onBack: () => void;
}

const Editor: React.FC<EditorProps> = ({ tool, onBack }) => {
  // === MODES ===
  const isChart = tool.category === ToolCategory.CHART;
  const isColor = tool.category === ToolCategory.COLOR;
  const isConversion = tool.category === ToolCategory.CONVERSION;
  const isImage = !isChart && !isColor && !isConversion;
  
  // Special Conversion modes
  const isBase64ToImage = tool.id === 'base64_to_image';
  const isImageToBase64 = tool.id === 'image_to_base64';
  const isFormatConversion = isConversion && !isBase64ToImage && !isImageToBase64;

  // === IMAGE STATE ===
  const [image, setImage] = useState<ImageState | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);
  
  // Image Params
  const [intensity, setIntensity] = useState(50); // 0-100 generic
  const [hslParams, setHslParams] = useState({ h: 0, s: 0, l: 0 }); // -100 to 100
  const [colorA, setColorA] = useState('#ff0000'); // Primary color
  const [colorB, setColorB] = useState('#00ff00'); // Secondary (replacement)
  const [boolA, setBoolA] = useState(true); // Generic toggle
  const [xy, setXy] = useState({ x: 0, y: 0 }); // For shift

  // === CHART STATE ===
  const [chartData, setChartData] = useState("12, 19, 3, 5, 2, 3");
  const [chartLabels, setChartLabels] = useState("Red, Blue, Yellow, Green, Purple, Orange");
  const [chartTitle, setChartTitle] = useState("HORROR METRICS");

  // === COLOR STATE ===
  const [baseColor, setBaseColor] = useState("#ff0000");
  const [secondaryColor, setSecondaryColor] = useState("#0000ff");
  const [schemeColors, setSchemeColors] = useState<string[]>([]);
  const [colorInfo, setColorInfo] = useState("");

  // === CONVERSION STATE ===
  const [textInput, setTextInput] = useState("");
  const [textOutput, setTextOutput] = useState("");

  // === IMAGE LOGIC ===
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const img = new Image();
        img.onload = () => {
           const resultStr = evt.target?.result as string;
           setImage({
             original: resultStr, modified: null,
             name: file.name, type: file.type, width: img.width, height: img.height
           });
           setPreviewUrl(resultStr);
           if(isImageToBase64) setTextOutput(resultStr);
        };
        img.src = evt.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageClick = (e: React.MouseEvent<HTMLImageElement>) => {
      if (tool.id !== 'image_color_picker') return;
      const img = imgRef.current;
      if (!img) return;
      const rect = img.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const scaleX = img.naturalWidth / img.clientWidth;
      const scaleY = img.naturalHeight / img.clientHeight;
      const imgX = Math.floor(x * scaleX);
      const imgY = Math.floor(y * scaleY);
      if (imgX < 0 || imgX >= img.naturalWidth || imgY < 0 || imgY >= img.naturalHeight) return;
      const canvas = document.createElement('canvas');
      canvas.width = 1; canvas.height = 1;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, imgX, imgY, 1, 1, 0, 0, 1, 1);
      const p = ctx.getImageData(0, 0, 1, 1).data;
      setColorA(rgbToHex(p[0], p[1], p[2]));
  };

  const processImage = useCallback(async () => {
      if (isBase64ToImage) {
          if(!textInput) return;
          setPreviewUrl(textInput);
          return;
      }
      if(!image || !image.original) return;
      if (tool.id === 'image_color_picker') return;

      setProcessing(true);
      try {
          const img = await loadImage(image.original);
          let w = img.width;
          let h = img.height;

          if (tool.id === 'duplicate') w *= 2;
          if (tool.id === 'resize') { const scale = 0.1 + (intensity/50); w = Math.floor(w * scale); h = Math.floor(h * scale); }
          if (tool.id === 'crop') { const cropFactor = intensity / 100; w = w * (1 - cropFactor * 0.5); h = h * (1 - cropFactor * 0.5); }

          if (w < 1 || h < 1) return; 

          const canvas = getCanvas(w, h);
          const ctx = canvas.getContext('2d');
          if(!ctx) return;
          
          if (tool.id === 'duplicate') { ctx.drawImage(img, 0, 0); ctx.drawImage(img, img.width, 0); }
          else if (tool.id === 'resize') ctx.drawImage(img, 0, 0, w, h);
          else if (tool.id === 'crop') {
              const sx = (img.width - w)/2; const sy = (img.height - h)/2;
              ctx.drawImage(img, sx, sy, w, h, 0, 0, w, h);
          } else if (tool.id === 'symmetric') {
               applySymmetric(ctx, img, w, h, boolA);
          } else {
              ctx.drawImage(img, 0, 0);
          }

          if (tool.category === ToolCategory.FILTER) {
              if (['saturation', 'hue', 'vibrance'].includes(tool.id)) {
                  applyHSLVibrance(ctx, w, h, tool.id as any, (intensity - 50) * 2);
              } else if (tool.id === 'hsl') {
                  applyHSLVibrance(ctx, w, h, 'hsl', hslParams.h, hslParams.s, hslParams.l);
              } else {
                  applyFilter(ctx, w, h, tool.id, intensity / 100); 
              }
          } 
          else if (tool.category === ToolCategory.MANIPULATION) {
             if (tool.id === 'flip') applyFlip(ctx, img, boolA);
             if (tool.id === 'rotate') applyRotate(ctx, img, intensity * 3.6); 
             if (tool.id === 'round_corners') applyRoundCorners(ctx, w, h, (intensity/100) * (Math.min(w, h)/2));
             if (tool.id === 'crop_circle') applyCropCircle(ctx, w, h);
             if (tool.id === 'grid_overlay') applyGrid(ctx, w, h, intensity + 10, colorA);
             if (tool.id === 'add_border') applyBorder(ctx, w, h, intensity, colorA);
             if (tool.id === 'fill_transparent') applyFillTransparent(ctx, w, h, hexToRgb(colorA));
             if (tool.id === 'overlay') applyOverlay(ctx, w, h, colorA, intensity/100);
             if (tool.id === 'remove_color') applyRemoveColor(ctx, w, h, hexToRgb(colorA), intensity);
             if (tool.id === 'replace_color') applyReplaceColor(ctx, w, h, hexToRgb(colorA), hexToRgb(colorB), intensity);
          }

          let mime = image.type;
          if (tool.id.includes('to_jpg')) mime = 'image/jpeg';
          if (tool.id.includes('to_png')) mime = 'image/png';
          if (tool.id.includes('to_webp')) mime = 'image/webp';
          
          // SET QUALITY TO 1.0 FOR MAX MB SIZE AND CLARITY
          setPreviewUrl(canvas.toDataURL(mime, 1.0));
      } finally {
          setProcessing(false);
      }
  }, [image, tool, intensity, colorA, colorB, boolA, hslParams, xy, textInput, isBase64ToImage]);

  useEffect(() => {
      if(isChart) {
          const canvas = document.createElement('canvas');
          canvas.width = 800; canvas.height = 600;
          const ctx = canvas.getContext('2d');
          if(ctx) {
              renderChart(ctx, 800, 600, {
                  type: tool.id,
                  data: chartData.split(',').map(n => parseFloat(n.trim()) || 0),
                  labels: chartLabels.split(',').map(s => s.trim()),
                  colors: ['#ef4444', '#b91c1c', '#7f1d1d', '#450a0a'],
                  title: chartTitle
              });
              setPreviewUrl(canvas.toDataURL());
          }
      } else if (isColor) {
           const colors = generateScheme(baseColor, tool.id.replace('_scheme',''), intensity, secondaryColor);
           setSchemeColors(colors);
           if (tool.id === 'convert_color' || tool.id === 'color_picker') setColorInfo(getColorInfo(baseColor));
      } else {
          const t = setTimeout(processImage, 50);
          return () => clearTimeout(t);
      }
  }, [processImage, isChart, isColor, tool.id, chartData, chartLabels, chartTitle, baseColor, secondaryColor, intensity]);

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0a0a] text-red-100 flex flex-col animate-fade-in overflow-hidden">
        
        {/* Header */}
        <div className="h-16 border-b border-red-900/30 flex items-center justify-between px-6 bg-[#050505]">
             <div className="flex items-center gap-3">
                 <div className="p-2 bg-red-900/20 rounded-full text-red-500">
                     {isChart ? <BarChart2 size={20} /> : isColor ? <Palette size={20} /> : isConversion ? <ArrowRight size={20} /> : <Layers size={20} />}
                 </div>
                 <div>
                     <h2 className="font-bold text-xl text-red-500 uppercase tracking-widest">{tool.name}</h2>
                     <p className="text-[10px] text-red-700 font-mono">{tool.category} MODULE ACTIVE</p>
                 </div>
             </div>
             <button onClick={onBack} className="p-2 hover:bg-red-900/20 rounded-full text-red-500 transition">
                 <X size={24} />
             </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
            
            {/* Sidebar Controls */}
            <div className="w-80 border-r border-red-900/20 bg-[#080808] p-6 overflow-y-auto space-y-8 scrollbar-thin flex-shrink-0">
                
                <AdSlot type="sidebar" className="mb-4" />

                {(isImage || isFormatConversion || isImageToBase64) && !image && (
                   <div className="text-center p-8 border-2 border-dashed border-red-900/30 rounded">
                       <Upload className="mx-auto mb-4 text-red-800" />
                       <label className="block w-full py-3 bg-red-900/20 hover:bg-red-900/40 text-red-400 font-bold rounded cursor-pointer transition">
                           LOAD IMAGE
                           <input type="file" onChange={handleFileChange} className="hidden" />
                       </label>
                   </div>
                )}

                {isImage && image && (
                    <div className="space-y-6">
                        {['flip', 'symmetric'].includes(tool.id) && (
                            <div>
                                <label className="text-xs font-bold text-red-500 block mb-2">DIRECTION</label>
                                <button onClick={() => setBoolA(!boolA)} className="w-full py-2 bg-red-900/20 text-red-300 border border-red-900/50 rounded flex items-center justify-center gap-2">
                                    {boolA ? <MoveHorizontal size={14} /> : <MoveVertical size={14} />}
                                    {boolA ? 'HORIZONTAL' : 'VERTICAL'}
                                </button>
                            </div>
                        )}
                        {!['hsl', 'image_color_picker'].includes(tool.id) && (
                            <div>
                                <label className="text-xs font-bold text-red-500 mb-2 block flex justify-between">
                                    <span>INTENSITY</span><span>{intensity}</span>
                                </label>
                                <input type="range" min="0" max="100" value={intensity} onChange={e=>setIntensity(parseInt(e.target.value))} className="w-full accent-red-600 h-2 bg-red-950 rounded-lg" />
                            </div>
                        )}
                        {['add_border','grid_overlay','fill_transparent','overlay','remove_color','replace_color'].includes(tool.id) && (
                           <div className="space-y-2">
                               <label className="text-xs font-bold text-red-500 block">{tool.id === 'replace_color' ? 'TARGET' : 'COLOR'}</label>
                               <input type="color" value={colorA} onChange={e=>setColorA(e.target.value)} className="h-10 w-full bg-transparent border border-red-900/50 rounded" />
                           </div>
                        )}
                    </div>
                )}

                {previewUrl && (
                    <div className="pt-8 border-t border-red-900/20">
                       <a href={previewUrl} download={`khan_${tool.id}.png`} className="flex w-full items-center justify-center gap-2 py-3 bg-red-800 text-white font-bold rounded shadow-lg hover:bg-red-700 transition">
                           <Download size={18} /> SAVE RESULT
                       </a>
                    </div>
                )}

                <AdSlot type="rectangle" className="mt-8" />
            </div>

            {/* Main Preview Area */}
            <div className="flex-1 bg-[#050505] relative flex flex-col items-center justify-center p-8 bg-[repeating-conic-gradient(#111_0%_25%,_#050505_0%_50%)] bg-[length:20px_20px] overflow-hidden">
                
                {(previewUrl && !isColor) ? (
                    <div className="relative shadow-2xl border border-red-900/20 max-w-full max-h-[70vh] flex items-center justify-center overflow-auto">
                        <img 
                            src={previewUrl} 
                            ref={imgRef}
                            onClick={handleImageClick}
                            className={`max-h-full max-w-full object-contain ${tool.id === 'image_color_picker' ? 'cursor-crosshair' : ''}`} 
                            alt="preview" 
                        />
                        {processing && <div className="absolute inset-0 bg-black/50 flex items-center justify-center backdrop-blur-sm"><RefreshCw className="animate-spin text-red-500"/></div>}
                    </div>
                ) : (
                    <div className="text-red-900/30 text-center select-none">
                        <Grid size={64} className="mx-auto mb-4 opacity-20" />
                        <h3 className="text-2xl font-black tracking-widest uppercase">Input Required</h3>
                    </div>
                )}

                {/* Bottom Ad Banner in Editor */}
                <div className="mt-auto pt-8">
                    <AdSlot type="leaderboard" />
                </div>
            </div>
        </div>
    </div>
  );
};

export default Editor;
